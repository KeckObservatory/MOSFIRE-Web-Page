<?xml version="1.0" encoding="UTF-8"?>
<!-- DWXMLSource="q0207_pa_0.xml" -->
<!DOCTYPE xsl:stylesheet [
	<!ENTITY nbsp   "&#160;">
	<!ENTITY copy   "&#169;">
	<!ENTITY reg    "&#174;">
	<!ENTITY trade  "&#8482;">
	<!ENTITY mdash  "&#8212;">
	<!ENTITY ldquo  "&#8220;">
	<!ENTITY rdquo  "&#8221;"> 
	<!ENTITY pound  "&#163;">
	<!ENTITY yen    "&#165;">
	<!ENTITY euro   "&#8364;">
]>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:output method="html" encoding="UTF-8" doctype-public="-//W3C//DTD XHTML 1.0 Transitional//EN" doctype-system="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"/>
<xsl:template match="/">

<style type="text/css">
html, body
{
	background-color:#EAF3EC;
	margin:0;
	padding:0;
	left:0;
	margin-top: 0px;
	padding-top: 0px;
}
body 
{
	margin: 10px;
}

h1
{
	font-family: Verdana, Geneva, sans-serif;
	margin-top: 0;
}

h3 
{
	font-family:Verdana, Geneva, sans-serif;
	font-style:oblique;
}
table 
{
	border:none;
	outline:solid;
	outline-color:#C0CBD6
}
thead
{
	vertical-align:bottom;
}
th
{
	background-color:#C0CBD6;
	font-family:Verdana, Geneva, sans-serif;
	font-size:12px;
}
td 
{
	font-family:"Courier New", Courier, monospace;
	font-size:12px;
	padding-left:5px;
	padding-right:5px;
	white-space:nowrap;
}
.evenRow
{
	background-color:#F3F7FA;
}
.oddRow
{
	background-color:#FFF;
}
.MaskName {
	font-family:"Lucida Console", Monaco, monospace;
	font-style:normal;
	font-size:24px;
	font-weight:bold;
	padding-left:15px;
}
.MaskLabel 
{
	font-family:Verdana, Geneva, sans-serif;
	font-weight:bold;
}
.MaskInfo
{
	font-size:16px;
	padding-left:15px;
}
.VerticalTableHeader
{
	text-align:right;
	white-space:nowrap;
}
.GenericText
{
	font-family:Verdana, Geneva, sans-serif;
	font-size:16px;
}
</style>
    
    
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
<title>MOSFIRE Slit Configuration</title>
</head>

<body>
<h1>MOSFIRE Slit Configuration</h1>
<span class="MaskLabel">MSC Version: </span><span class="GenericText"><xsl:value-of select="slitConfiguration/@mscVersion" /></span>
<hr/>

<table>
  <tr class="evenRow">
    <th>Mask Name:</th>
    <td><span class="MaskName"><xsl:value-of select="slitConfiguration/maskDescription/@maskName"/></span></td>
  </tr>
  <tr class="oddRow">
    <th>Mask Center:</th>
    <td><span class="MaskInfo"> <xsl:value-of select="slitConfiguration/maskDescription/@centerRaH"/>h <xsl:value-of select="slitConfiguration/maskDescription/@centerRaM"/>m <xsl:value-of select="slitConfiguration/maskDescription/@centerRaS"/>s  <xsl:value-of select="slitConfiguration/maskDescription/@centerDecD"/>d <xsl:value-of select="slitConfiguration/maskDescription/@centerDecM"/>m <xsl:value-of select="slitConfiguration/maskDescription/@centerDecS"/>s</span></td>
  </tr>
  <tr class="evenRow">
	<th>Mask PA:</th>
	<td><span class="MaskInfo"><xsl:value-of select="slitConfiguration/maskDescription/@maskPA"/> degrees</span></td>
  </tr>
</table>

<h3>Science Slits</h3>
<table>
  <thead align="center">
    <th>#</th>
    <th>RA</th>
    <th>Dec</th>
    <th>Width (arcsec)</th>
    <th>Length (arcsec)</th>
    <th>Target</th>
    <th>Priority</th>
    <th>Mag</th>
    <th>Center Distance (arcsec)</th>
    <th>Target RA</th>
    <th>Target Dec</th>
    <th>Target Epoch</th>
    <th>Target Equinox</th>
  </thead>
  <xsl:for-each select="slitConfiguration/scienceSlitConfig/scienceSlit">
    <xsl:variable name="rowStyle">
    	<xsl:choose>
			<xsl:when test="position() mod 2 = 0">evenRow</xsl:when>
			<xsl:otherwise>oddRow</xsl:otherwise>
        </xsl:choose>
    </xsl:variable>  <tr align="center" class="{$rowStyle}">
    <td><xsl:value-of select="@slitNumber"/></td>
    <td><xsl:value-of select="@slitRaH"/>h <xsl:value-of select="@slitRaM"/>m <xsl:value-of select="@slitRaS"/>s</td>
    <td><xsl:value-of select="@slitDecD"/>d <xsl:value-of select="@slitDecM"/>m <xsl:value-of select="@slitDecS"/>s</td>
    <td><xsl:value-of select="@slitWidthArcsec"/></td>
    <td><xsl:value-of select="@slitLengthArcsec"/></td>
    <td><xsl:value-of select="@target"/></td>
    <td><xsl:value-of select="@targetPriority"/></td>
    <td><xsl:value-of select="@targetMag"/></td>
    <td><xsl:value-of select="@targetCenterDistance"/></td>
    <td><xsl:value-of select="@targetRaH"/>h <xsl:value-of select="@targetRaM"/>m <xsl:value-of select="@targetRaS"/>s</td>
    <td><xsl:value-of select="@targetDecD"/>d <xsl:value-of select="@targetDecM"/>m <xsl:value-of select="@targetDecS"/>s</td>
    <td><xsl:value-of select="@targetEpoch"/></td>
    <td><xsl:value-of select="@targetEquinox"/></td>
  </tr>
  </xsl:for-each>
</table>

<h3>Mechanical Slit Description</h3>

<table width="600">
	<thead align="center">
   	  <th>Row</th>
    	<th>Left Bar #</th>
    	<th>Right Bar #</th>
    	<th>Left Bar Pos (mm)</th>
    	<th>Right Bar Pos (mm)</th>
    	<th>Center Position (arcsec)</th>
    	<th>Width (arcsec)</th>
    	<th>Target</th>
  </thead>
  	<xsl:for-each select="slitConfiguration/mechanicalSlitConfig/mechanicalSlit">
    <xsl:variable name="rowStyle">
    	<xsl:choose>
			<xsl:when test="position() mod 2 = 0">evenRow</xsl:when>
			<xsl:otherwise>oddRow</xsl:otherwise>
        </xsl:choose>
    </xsl:variable>
    <tr align="center" class="{$rowStyle}">
      <td><xsl:value-of select="@slitNumber"/></td>
      <td><xsl:value-of select="@leftBarNumber"/></td>
      <td><xsl:value-of select="@rightBarNumber"/></td>
      <td><xsl:value-of select="@leftBarPositionMM"/></td>
      <td><xsl:value-of select="@rightBarPositionMM"/></td>
      <td><xsl:value-of select="@centerPositionArcsec"/></td>
      <td><xsl:value-of select="@slitWidthArcsec"/></td>
      <td><xsl:value-of select="@target"/></td>
    </tr>
  </xsl:for-each>
</table>

<h3>Alignment Boxes</h3>
<table>
  <thead align="center">
    <th>Mech Slit #</th>
    <th>Left Bar #</th>
    <th>Right Bar #</th>
    <th>Left Bar Pos (mm)</th>
    <th>Right Bar Pos (mm)</th>
    <th>Center Position (arcsec)</th>
    <th>Width (arcsec)</th>
    <th>Target</th>
    <th>Priority</th>
    <th>Mag</th>
    <th>Center Distance (arcsec)</th>
    <th>Target RA</th>
    <th>Target Dec</th>
    <th>Target Epoch</th>
    <th>Target Equinox</th>
  </thead>
  <xsl:for-each select="slitConfiguration/alignment/alignSlit">
    <xsl:variable name="rowStyle">
    	<xsl:choose>
			<xsl:when test="position() mod 2 = 0">evenRow</xsl:when>
			<xsl:otherwise>oddRow</xsl:otherwise>
        </xsl:choose>
    </xsl:variable>  <tr align="center" class="{$rowStyle}">
    <td><xsl:value-of select="@mechSlitNumber"/></td>
    <td><xsl:value-of select="@leftBarNumber"/></td>
    <td><xsl:value-of select="@rightBarNumber"/></td>
    <td><xsl:value-of select="@leftBarPositionMM"/></td>
    <td><xsl:value-of select="@rightBarPositionMM"/></td>
    <td><xsl:value-of select="@centerPositionArcsec"/></td>
    <td><xsl:value-of select="@slitWidthArcsec"/></td>
    <td><xsl:value-of select="@target"/></td>
    <td><xsl:value-of select="@targetPriority"/></td>
    <td><xsl:value-of select="@targetMag"/></td>
    <td><xsl:value-of select="@targetCenterDistance"/></td>
    <td><xsl:value-of select="@targetRaH"/>h <xsl:value-of select="@targetRaM"/>m <xsl:value-of select="@targetRaS"/>s</td>
    <td><xsl:value-of select="@targetDecD"/>d <xsl:value-of select="@targetDecM"/>m <xsl:value-of select="@targetDecS"/>s</td>
    <td><xsl:value-of select="@targetEpoch"/></td>
    <td><xsl:value-of select="@targetEquinox"/></td>
  </tr>
  </xsl:for-each>
</table>

<h3>MASCGEN Arguments</h3>

<p><span class="MaskLabel">Inputs:</span></p>
<table>
	<tr class="evenRow">
      <th class="VerticalTableHeader">Target List:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/@targetList"/></td>
    </tr>
	<tr class="oddRow">
      <th class="VerticalTableHeader">X Range:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/@xrange"/> arcmin</td>
    </tr>
	<tr class="evenRow">
      <th class="VerticalTableHeader">X Center:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/@xcenter"/> arcmin</td>
    </tr>
	<tr class="oddRow">
      <th class="VerticalTableHeader">Slit Width:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/@slitWidthArcsec"/> arcsec</td>
    </tr>
	<tr class="evenRow">
      <th class="VerticalTableHeader">Dither Space:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/@ditherSpace"/> arcsec</td>
    </tr>
	<tr class="oddRow">
      <th class="VerticalTableHeader">Min Align Stars:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/@minAlignStars"/></td>
    </tr>
	<tr class="evenRow">
      <th class="VerticalTableHeader">Star Dither Space:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/@starDitherSpace"/> arcsec</td>
    </tr>
	<tr class="oddRow">
      <th class="VerticalTableHeader">Center Position:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/center/@raHours"/>h <xsl:value-of select="slitConfiguration/mascgenArguments/inputs/center/@raMinutes"/>m <xsl:value-of select="slitConfiguration/mascgenArguments/inputs/center/@raSeconds"/>s  <xsl:value-of select="slitConfiguration/mascgenArguments/inputs/center/@decDegrees"/>d <xsl:value-of select="slitConfiguration/mascgenArguments/inputs/center/@decMinutes"/>m <xsl:value-of select="slitConfiguration/mascgenArguments/inputs/center/@raSeconds"/>s</td>
    </tr>
	<tr class="evenRow">
      <th class="VerticalTableHeader">Uses Center of Priority:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/center/@useCenterOfPriority"/></td>
    </tr>
	<tr class="oddRow">
      <th class="VerticalTableHeader">Position Angle:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/center/@positionAngle"/> degrees</td>
    </tr>
	<tr class="evenRow">
      <th class="VerticalTableHeader">X Steps:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/steps/@xSteps"/></td>
	</tr>
	<tr class="oddRow">
      <th class="VerticalTableHeader">X Step Size:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/steps/@xStepsSize"/> arcsec</td>
    </tr>
	<tr class="evenRow">
      <th class="VerticalTableHeader">Y Steps:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/steps/@ySteps"/></td>
	</tr>
	<tr class="oddRow">
      <th class="VerticalTableHeader">Y Step Size:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/steps/@yStepsSize"/> arcsec</td>
    </tr>
	<tr class="evenRow">
      <th class="VerticalTableHeader">PA Steps:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/steps/@paSteps"/></td>
	</tr>
	<tr class="oddRow">
      <th class="VerticalTableHeader">PA Step Size:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/inputs/steps/@paStepsSize"/> degrees</td>
    </tr>
</table>
<p><span class="MaskLabel">Outputs:</span></p>
<table>
	<tr class="evenRow">
      <th class="VerticalTableHeader">Autoname Output Files:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/outputs/@autonameOutput"/></td>
    </tr>
	<tr class="oddRow">
      <th class="VerticalTableHeader">Root Directory:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/outputs/directory/@root"/></td>
    </tr>
	<tr class="evenRow">
      <th class="VerticalTableHeader">Subdirectory:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/outputs/directory/@subdirectory"/></td>
    </tr>
	<tr class="oddRow">
      <th class="VerticalTableHeader">Use Mask Name as Subdir:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/outputs/directory/@useMaskNameSubdir"/></td>
    </tr>
	<tr class="evenRow">
      <th class="VerticalTableHeader">MASCGEN Params:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/outputs/@mascgenParams"/></td>
    </tr>
	<tr class="oddRow">
      <th class="VerticalTableHeader">MSC File:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/outputs/@mscFile"/></td>
    </tr>
	<tr class="evenRow">
      <th class="VerticalTableHeader">Slit List:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/outputs/@slitList"/></td>
    </tr>
	<tr class="oddRow">
      <th class="VerticalTableHeader">Science Mask Script:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/outputs/maskScript/@science"/></td>
    </tr>
	<tr class="evenRow">
      <th class="VerticalTableHeader">Align Mask Script:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/outputs/maskScript/@align"/></td>
    </tr>
	<tr class="oddRow">
      <th class="VerticalTableHeader">Keck Star List:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/outputs/@starList"/></td>
    </tr>
	<tr class="evenRow">
      <th class="VerticalTableHeader">DS9 Regions:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/outputs/@ds9Regions"/></td>
    </tr>
	<tr class="oddRow">
      <th class="VerticalTableHeader">Targets In Mask:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/outputs/@targetsInMask"/></td>
    </tr>
	<tr class="evenRow">
      <th class="VerticalTableHeader">All Targets:</th>
      <td><xsl:value-of select="slitConfiguration/mascgenArguments/outputs/@allTargets"/></td>
    </tr>
</table>
</body>
</html>

</xsl:template>
</xsl:stylesheet>