@echo off
IF "%MAGMA_OUTPUT_DIR%" == "" SET MAGMA_OUTPUT_DIR=%USERPROFILE%
IF "%MAGMA_TARGET_LIST_DIR%" == "" SET MAGMA_TARGET_LIST_DIR=%CD%

FOR /F "usebackqskip=1" %%f IN (`wmic desktopmonitor get screenheight`) DO IF %%f GTR 1 set SCREENYS=%%f

echo %SCREENYS%

IF %SCREENYS% LSS 1000 (
java -Djava.security.policy=mosfire.java.policy -Dawt.useSystemAAFontSettings=on -jar magma.jar cfg=offline_condensed_magma_cfg.xml
) ELSE (
java -Djava.security.policy=mosfire.java.policy -Dawt.useSystemAAFontSettings=on -jar magma.jar cfg=offline_magma_cfg.xml
)
