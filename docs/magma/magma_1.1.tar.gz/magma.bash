#!/bin/bash

echo
if [ ! -n "$MAGMA_OUTPUT_DIR" ]; then
   echo "Setting MAGMA_OUTPUT_DIR to default (home)"
   export MAGMA_OUTPUT_DIR=~
fi

if [ ! -n "$MAGMA_TARGET_LIST_DIR" ]; then
   echo "Setting MAGMA_TARGET_LIST_DIR to default (.)"
   export MAGMA_TARGET_LIST_DIR=`pwd` 
fi

echo MAGMA_OUTPUT_DIR is $MAGMA_OUTPUT_DIR
echo MAGMA_TARGET_LIST_DIR is $MAGMA_TARGET_LIST_DIR

platform="unknown"
unamestr=`uname`
minfullys=1000
cfg="offline_magma_cfg.xml"
smallcfg="offline_condensed_magma_cfg.xml"
javaopts1="-Dawt.useSystemAAFontSettings=on"
javaopts2="-Dignore"
javaopts3="-Dignore"
javaopts4="-Dignore"

if [[ "$unamestr" == 'Linux' ]]; then
   echo "Running on Linux"
   platform='linux'
elif [[ "$unamestr" == 'Darwin' ]]; then
   echo "Running on a Mac"
   platform='mac'
elif [[ "$unamestr" == 'SunOS' ]]; then
   echo "Running on Solaris"
   platform='solaris'
fi

if [[ $platform == 'mac' ]]; then
   echo "Using Mac Config File"
   cfg="mac_offline_magma_cfg.xml"
   smallcfg="mac_offline_condensed_magma_cfg.xml"
   javaopts1="-Dapple.laf.useScreenMenuBar=true"
   javaopts2="-Dcom.apple.mrj.application.apple.menu.about.name=MAGMA"
   javaopts3="-Dapple.awt.antialiasing=on"
   javaopts4="-Dapple.awt.textantialiasing=on"
fi

# get number of vertical pixels in screen
ys=`xdpyinfo | grep dimensions | cut -dx -f2 | cut -d" " -f1`

# if ys obtained, and smaller than minimum value needed for
# full size gui, used condensed settings.
if [ -n "$ys" ]; then 
    if [ "$ys" -lt "$minfullys" ]; then
	cfg=$smallcfg
    fi
fi

java -Djava.security.policy=mosfire.java.policy "$javaopts1" "$javaopts2" "$javaopts3" "$javaopts4"  -jar magma.jar cfg="$cfg"
